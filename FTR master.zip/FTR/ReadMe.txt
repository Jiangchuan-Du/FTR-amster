Input 放入输入的数据TADPOLE_test_ro.csv 第一列是Patient ID 第二列是Diagnosis(1代表CN,2代表MCI,3代表AD) 后面是biomarkers，需要提前regress out sex,age,ICV
Output 输出 1) stage.csv 第一列是Patient ID 第二列是stage
		2) subtype.csv 第一列是Patient ID 第二列是subtype
		3) trajectory1.csv 第一个subtype的trajectory 行是不同的biomarkers 列是不同时间点biomarker的值 2,3同理
Run_FTR.m 运行程序
需要设置的参数：1）nsubtyp subtype的个数
		       2）max_ep 运行总共的epochs数量
                           3）max_iter 每个epoch所包含的iteration数量
